package tests;

import org.junit.jupiter.api.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.FormPage;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FormTest extends BaseTest {
    static FormPage formPage;
    static WebDriverWait wait;

    @BeforeAll
    static void init() {
        formPage = new FormPage(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Test
    @DisplayName("Test submit practice form")
    void testFormSubmit() {
        formPage.openForm();
        formPage.fillForm("Nguyen", "Van A", "abc@example.com", "0123456789");
        assertTrue(formPage.isSubmitted());
    }
}
