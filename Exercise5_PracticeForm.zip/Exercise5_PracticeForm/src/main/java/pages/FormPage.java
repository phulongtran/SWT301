package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FormPage extends BasePage {
    public FormPage(WebDriver driver) {
        super(driver);
    }

    // Locators
    private By firstName = By.id("firstName");
    private By lastName = By.id("lastName");
    private By email = By.id("userEmail");
    private By genderMale = By.xpath("//label[text()='Male']");
    private By mobile = By.id("userNumber");
    private By submitBtn = By.id("submit");
    private By successModal = By.className("modal-content");

    // Điều hướng đến form
    public void openForm() {
        navigateTo("https://demoqa.com/automation-practice-form");

        // Đóng popup nếu có
        try {
            WebElement closeAd = driver.findElement(By.id("close-fixedban"));
            if (closeAd.isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", closeAd);
            }
        } catch (NoSuchElementException ignored) {
        }
    }

    // Điền form và submit
    public void fillForm(String fName, String lName, String mail, String phone) {
        type(firstName, fName);
        type(lastName, lName);
        type(email, mail);
        click(genderMale);
        type(mobile, phone);

        // Scroll tới nút submit để tránh bị che
        WebElement submitElement = wait.until(ExpectedConditions.elementToBeClickable(submitBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitElement);

        click(submitBtn);
    }

    // Kiểm tra đã submit thành công chưa
    public boolean isSubmitted() {
        return isElementVisible(successModal);
    }
}
