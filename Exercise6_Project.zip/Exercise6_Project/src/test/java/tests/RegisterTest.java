package tests;

import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import pages.RegisterPage;
import utils.DriverFactory;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class RegisterTest {
    static WebDriver driver;
    static WebDriverWait wait;
    static RegisterPage registerPage;

    @BeforeAll
    static void setUp() {
        driver = DriverFactory.createDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        registerPage = new RegisterPage(driver);
    }

    @Test
    @Order(1)
    @DisplayName("Should register successfully with valid data")
    void testRegisterSuccess() {
        registerPage.navigate();
        registerPage.fillForm("Nguyen", "Van A", "abc123@gmail.com", "0987654321");
        registerPage.submit();

        WebElement popup = wait.until(ExpectedConditions.visibilityOfElementLocated(registerPage.getSuccessPopupLocator()));
        assertTrue(popup.getText().contains("Thanks for submitting the form"));
    }

    @AfterAll
    static void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
